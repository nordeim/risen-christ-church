export type Confidence = "Verified" | "Reasoned" | "Assumed";
export type Winner = "mary" | "risen" | "tie";

export interface SiteProfile {
  id: "mary" | "risen";
  short: string;
  name: string;
  place: string;
  chinese: string;
  tagline: string;
  vision: string;
  live: string;
  github: string;
  version: string;
  designRound: string;
  feast: string;
  founded: string;
  address: string;
  heroLine: string;
  fonts: string;
  tests: string;
  bundle: string;
  images: {
    hero: string;
    sanctuary: string;
    glass: string;
    chapel: string;
  };
}

export interface Dimension {
  id: string;
  name: string;
  mary: number;
  risen: number;
  winner: Winner;
  thesis: string;
  maryNote: string;
  risenNote: string;
  evidence: string;
  confidence: Confidence;
}

export const mary: SiteProfile = {
  id: "mary",
  short: "St Mary",
  name: "Church of St Mary of the Angels",
  place: "Bukit Batok",
  chinese: "天神之后圣母堂",
  tagline: "According to Thy Word.",
  vision: "Pray · Form · Go",
  live: "https://st-mary-of-angels.jesspete.shop/",
  github: "https://github.com/nordeim/st-mary-of-angels",
  version: "1.2.0",
  designRound: "Round 5 — Light of the Portiuncula",
  feast: "Our Lady of the Angels · 2 August",
  founded: "Parish 1970 · WOHA church 2004",
  address: "5 Bukit Batok East Ave 2",
  heroLine: "A Franciscan parish since 1970",
  fonts: "Fraunces 400/600/700 + Source Sans 3",
  tests: "25 unit files / 141 tests · 42 E2E",
  bundle: "387.43 kB singlefile",
  images: {
    hero: "https://st-mary-of-angels.jesspete.shop/images/hero-church.jpg",
    sanctuary: "https://st-mary-of-angels.jesspete.shop/images/sanctuary.jpg",
    glass: "https://st-mary-of-angels.jesspete.shop/images/stained-glass.jpg",
    chapel: "https://st-mary-of-angels.jesspete.shop/images/chapel-interior.jpg",
  },
};

export const risen: SiteProfile = {
  id: "risen",
  short: "Risen Christ",
  name: "Church of the Risen Christ",
  place: "Toa Payoh",
  chinese: "耶稣复活堂",
  tagline: "He is risen.",
  vision: "Grateful · Faithful · Sent",
  live: "https://risen-christ.jesspete.shop/",
  github: "https://github.com/nordeim/risen-christ-church",
  version: "1.4.3",
  designRound: "Round 7 — Honest Light",
  feast: "Easter",
  founded: "Blessed 3 July 1971",
  address: "91 Toa Payoh Central",
  heroLine: "A parish since 1971 · 耶稣复活堂",
  fonts: "Fraunces 500/600/700 + Source Sans 3",
  tests: "32 unit files / 184 tests · 48 E2E",
  bundle: "395.66 kB singlefile",
  images: {
    hero: "https://risen-christ.jesspete.shop/images/hero-church.jpg",
    sanctuary: "https://risen-christ.jesspete.shop/images/sanctuary.jpg",
    glass: "https://risen-christ.jesspete.shop/images/stained-glass.jpg",
    chapel: "https://risen-christ.jesspete.shop/images/chapel-interior.jpg",
  },
};

export const shared = [
  "Identical shrine-* token palette (cream #faf6ec, maroon-950 #200a0a, gold-500 #c3963f, pine, terracotta)",
  "Fraunces display + Source Sans 3 body, loaded from Google Fonts",
  "HashRouter SPA, 10 pages, 17 routes, 7 legacy aliases",
  "Sacred Motion: rise-in stagger, 20s Ken Burns hero, gold-rule draw, card-lift, img-zoom, grain + adobe texture",
  "Global prefers-reduced-motion collapse; gold focus-visible rings",
  "Skip link, scroll progress, back-to-top, mobile drawer-as-modal with focus trap",
  "Mass “Today” chip via massDayKey; EventMeta category chips; History sticky story column",
];

export const dimensions: Dimension[] = [
  {
    id: "identity",
    name: "Visual identity",
    mary: 8.6,
    risen: 8.4,
    winner: "mary",
    thesis:
      "Both wear the same liturgical coat. St Mary’s copy and architecture give that coat a more specific body.",
    maryNote:
      "Portiuncula, OFM custody, WOHA “house of light,” and “According to Thy Word.” The hill in Bukit Batok is a place, not a theme.",
    risenNote:
      "“He is risen.” is the stronger sentence. The bilingual eyebrow (耶稣复活堂) is a genuine local cue. The visual system, though, is still St Mary’s shrine language ported east.",
    evidence:
      "Home.tsx heroes; README design-system tables are byte-identical on tokens; Risen README states the St Mary lineage (Rother → St Joseph → St Mary → Risen).",
    confidence: "Verified",
  },
  {
    id: "type",
    name: "Typography",
    mary: 8.5,
    risen: 8.6,
    winner: "risen",
    thesis:
      "Same pairing, different optical weight. Risen drops Fraunces 400 for 500 — a quieter, more contemporary display.",
    maryNote:
      "Fraunces 400/600/700. Display headings on cream are excellent; the 400 cut reads a touch spindly at 7xl on dark heroes.",
    risenNote:
      "Fraunces 500/600/700. The medium cut holds the cream-on-maroon hero without thinning. Source Sans 3 body, tracking, and text-balance are shared.",
    evidence:
      "Live index.html font links: St Mary requests Fraunces wght 400; Risen requests 500. Both load Source Sans 3 400/600/700.",
    confidence: "Verified",
  },
  {
    id: "atmosphere",
    name: "Color & atmosphere",
    mary: 8.4,
    risen: 8.7,
    winner: "risen",
    thesis:
      "The palette is shared. Atmosphere is not — interior pages on Risen let the photography speak.",
    maryNote:
      "PageHero image at opacity-35 under a /50 → /70 → solid maroon stack. Stained glass and sanctuary shots open every interior page on the same murky note. Gold bloom on dark bands is present (round 5 P-9).",
    risenNote:
      "Round 7 P-9 lifts PageHero to opacity-45 and softens the right/bottom gradients. Cream type still sits on the darkened left field. Interiors feel lit rather than smoked.",
    evidence:
      "docs/design-enhancement-round7 (R7-9 / P-9); St Mary PageHero still at the round-5 opacity. Token tables match exactly.",
    confidence: "Reasoned",
  },
  {
    id: "motion",
    name: "Motion craft",
    mary: 8.2,
    risen: 8.8,
    winner: "risen",
    thesis:
      "Both sites move with liturgical restraint. Risen’s motion is more honest about what is clickable.",
    maryNote:
      "Rise-in, Ken Burns, card-lift, img-zoom, gold-rule, halo-pulse — a complete Sacred Motion set. card-lift is applied to info cards that go nowhere.",
    risenNote:
      "Same kit, plus card-tint for non-interactive surfaces, print override on .reveal, and IntersectionObserver rootMargin so reveals do not pop late. Lift is reserved for links.",
    evidence:
      "src/index.css utilities; round-7 R7-1 / R7-8; Home.tsx featured events are <Link> on Risen, <article> on St Mary.",
    confidence: "Verified",
  },
  {
    id: "ia",
    name: "Information architecture",
    mary: 8.7,
    risen: 8.7,
    winner: "tie",
    thesis:
      "A parish site is a utility with a soul. Both get the jobs-to-be-done right.",
    maryNote:
      "Home → Mass times / The parish. Worship #mass #confession #visit. Six ministries with jump nav. FAQ, Give, Serve. Alias routes preserve old bookmarks.",
    risenNote:
      "Identical map, parish-specific payload: five Sunday Masses, monthly Bahasa/Tamil/Tagalog, PayNow UEN, bulletin FlipHTML5. Same HashRouter double-hash restore.",
    evidence:
      "src/data/nav.ts and App.tsx routing tables in both READMEs — 17 routes, 5 alias groups, 10 pages.",
    confidence: "Verified",
  },
  {
    id: "honesty",
    name: "Interaction honesty",
    mary: 7.6,
    risen: 9.1,
    winner: "risen",
    thesis:
      "The largest UX gap. Lift plus shadow is a promise. St Mary makes that promise on cards that do not go anywhere.",
    maryNote:
      "Worship devotions, Give options, Serve roles, About pillars, priest cards, NewsEvents, and Home featured events all use card-lift. Hover says “click.” Click does nothing.",
    risenNote:
      "card-tint (warm gold wash, no translate) on info surfaces. card-lift kept only on genuine links (grounds, featured events → /news-events). PayNow is the one Give card with a gold top rule.",
    evidence:
      "Round-7 R7-8 / P-8 and card-affordances tests (6). St Mary Home.tsx featured events remain unlinked articles with card-lift.",
    confidence: "Verified",
  },
  {
    id: "wayfinding",
    name: "Wayfinding",
    mary: 8.0,
    risen: 8.9,
    winner: "risen",
    thesis:
      "Both headers are sticky editorial bars. Only Risen draws a gold hairline under the current route, and only Risen spies the ministries page.",
    maryNote:
      "Active nav is gold text. Ministries pills take aria-current from the hash after a click — they do not follow the reader.",
    risenNote:
      "Desktop nav ::after hairline, scaleX on hover/focus/active. useScrollSpy marks the ministry in the middle of the viewport. Footer already had link-underline; the header now speaks the same grammar.",
    evidence:
      "Header.tsx after: utilities (Risen only); useScrollSpy.ts; e2e enhancements-round7 specs 5–6.",
    confidence: "Verified",
  },
  {
    id: "a11y",
    name: "Accessibility",
    mary: 8.3,
    risen: 8.8,
    winner: "risen",
    thesis:
      "Both clear WCAG 2.2 AA on the fundamentals. Risen is more robust when JavaScript or print is unkind.",
    maryNote:
      "Skip link (maroon-950 / gold-300, translateY hide), gold focus rings, reduced-motion global kill, drawer as modal with focus trap (round 4). .reveal { opacity: 0 } has no print override — below-fold content can vanish in print or if IntersectionObserver fails.",
    risenNote:
      "Skip link is a gold-500 plate on maroon-900 — higher contrast, no transform hide. Print forces .reveal visible. Reveal constructor is try/caught. Same reduced-motion and focus-trap contracts.",
    evidence:
      "Live HTML skip-link CSS; index.css print query on Risen only; Reveal.tsx round-7 P-1. Contrast of cream-on-maroon-950 is shared and sufficient.",
    confidence: "Reasoned",
  },
  {
    id: "closure",
    name: "Closure & composition",
    mary: 8.1,
    risen: 8.9,
    winner: "risen",
    thesis:
      "Pages should land, not drop. Risen closes more rooms.",
    maryNote:
      "Home dark CTA and Give “house of prayer” band exist. News & Events and FAQ still end at the grid/accordion and fall into the footer. History sticky column is excellent.",
    risenNote:
      "NewsEvents bulletin band, FAQ “Still have questions?” with tel/mailto, Worship sticky mercy column, Give PayNow as Von Restorff original. Serial-position endings on the pages that previously dead-ended.",
    evidence:
      "Round-7 R7-2/R7-3/R7-4; cta-bands tests; Give featured data-featured on PayNow.",
    confidence: "Verified",
  },
  {
    id: "character",
    name: "Parish character",
    mary: 9.0,
    risen: 8.5,
    winner: "mary",
    thesis:
      "A template becomes a parish when the sentences could not belong to anyone else.",
    maryNote:
      "Friars on a sociological hill, a WOHA nave of folded light, St Francis with a bird at the roundabout, Tamil at Saturday dusk. “You are not a visitor here. You are expected.” The building is famous; the site is worthy of it.",
    risenNote:
      "First air-conditioned church in Singapore, Ho Ping Centre 1969, Velankanni, Simbang Gabi, five languages at one altar. The facts are distinctive. The visual grammar still says “shrine-maroon,” not “Toa Payoh Central.”",
    evidence:
      "Home welcome copy and lifeTimeline in both content.ts files. Token and component inventories remain shared.",
    confidence: "Reasoned",
  },
];

export const aestheticIds = ["identity", "type", "atmosphere", "character"];
export const uxIds = ["motion", "ia", "honesty", "wayfinding", "a11y", "closure"];

export function average(ids: string[]): { mary: number; risen: number } {
  const set = dimensions.filter((d) => ids.includes(d.id));
  const marySum = set.reduce((s, d) => s + d.mary, 0);
  const risenSum = set.reduce((s, d) => s + d.risen, 0);
  return {
    mary: marySum / set.length,
    risen: risenSum / set.length,
  };
}

export const overall = average(dimensions.map((d) => d.id));
export const aesthetic = average(aestheticIds);
export const ux = average(uxIds);

export const findings = [
  {
    severity: "High" as const,
    site: "St Mary of the Angels",
    title: "Hover lies on dead cards",
    detail:
      "card-lift (translateY + shadow + gold border) is the site’s “this is a link” signal. It is attached to Give options, Serve roles, devotion cards, About pillars, priest cards, NewsEvents, and Home featured events — none of which navigate. Round 7 named this R7-8 on the sister port and fixed it with card-tint.",
  },
  {
    severity: "Medium" as const,
    site: "St Mary of the Angels",
    title: "PageHero smokes the interiors",
    detail:
      "Interior photography sits at opacity-35 under a heavy maroon gradient. Give and FAQ open on the same near-black field. The WOHA building is a house of light; the interior templates do not admit it.",
  },
  {
    severity: "Medium" as const,
    site: "St Mary of the Angels",
    title: "Reveal can hide print content",
    detail:
      ".reveal defaults to opacity 0. There is no @media print override and no IntersectionObserver constructor guard. Below-fold History, Give, and Ministries content can be blank in print or capture contexts.",
  },
  {
    severity: "Low" as const,
    site: "St Mary of the Angels",
    title: "Active nav is color only",
    detail:
      "Desktop current-route state is gold text. The footer already draws a gold underline. The header does not, so wayfinding is weaker at the place it matters most.",
  },
  {
    severity: "Low" as const,
    site: "Church of the Risen Christ",
    title: "A port still wearing another parish’s coat",
    detail:
      "Tokens, motion names (shrine-*), and the cream-maroon-gold liturgical editorial system were inherited wholesale. The Easter identity is carried by copy and photography, not by a palette or emblem of its own. Distinctiveness is literary, not chromatic.",
  },
  {
    severity: "Informational" as const,
    site: "Both",
    title: "CSP and host headers diverge",
    detail:
      "St Mary’s live CSP still allowlists images.pexels.com and upload.wikimedia.org (unused). Risen tightened img-src to 'self' data blob. Neither live host currently serves the public/_headers HSTS set — a documented ops gap, not a visual one.",
  },
];

export const tokens = [
  { name: "cream", hex: "#faf6ec", use: "Page ground" },
  { name: "parchment", hex: "#f2e9d6", use: "Section bands" },
  { name: "ink", hex: "#2a2115", use: "Body text" },
  { name: "maroon-700", hex: "#55191a", use: "Display headings" },
  { name: "maroon-950", hex: "#200a0a", use: "Hero / footer" },
  { name: "gold-500", hex: "#c3963f", use: "Primary button" },
  { name: "gold-300", hex: "#e2bf72", use: "Eyebrow on dark" },
  { name: "pine-500", hex: "#335840", use: "Accent / weave" },
];
