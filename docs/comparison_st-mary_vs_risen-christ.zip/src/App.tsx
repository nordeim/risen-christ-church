import { useEffect, useMemo, useState } from "react";
import { cn } from "./utils/cn";
import {
  aesthetic,
  dimensions,
  findings,
  mary,
  overall,
  risen,
  shared,
  tokens,
  ux,
  type Confidence,
  type SiteProfile,
  type Winner,
} from "./data";

const NAV = [
  { href: "#overview", label: "Overview" },
  { href: "#portraits", label: "Portraits" },
  { href: "#scores", label: "Scores" },
  { href: "#system", label: "System" },
  { href: "#dimensions", label: "Dimensions" },
  { href: "#findings", label: "Findings" },
  { href: "#verdict", label: "Verdict" },
];

function formatScore(n: number) {
  return n.toFixed(1);
}

function winnerLabel(w: Winner) {
  if (w === "tie") return "Tie";
  return w === "mary" ? "St Mary" : "Risen Christ";
}

function ConfidenceChip({ value }: { value: Confidence }) {
  return (
    <span className="inline-flex items-center gap-1.5 font-mono text-[0.65rem] uppercase tracking-[0.16em] text-muted">
      <span
        className={cn(
          "h-1.5 w-1.5 rounded-full",
          value === "Verified" && "bg-risen",
          value === "Reasoned" && "bg-gold",
          value === "Assumed" && "bg-muted",
        )}
        aria-hidden
      />
      {value}
    </span>
  );
}

function ScoreBar({
  maryScore,
  risenScore,
}: {
  maryScore: number;
  risenScore: number;
}) {
  return (
    <div className="grid gap-2" aria-hidden>
      <div className="flex items-center gap-3">
        <span className="w-16 shrink-0 font-mono text-[0.65rem] uppercase tracking-[0.14em] text-mary">
          Mary
        </span>
        <div className="h-[3px] flex-1 bg-rule">
          <div
            className="h-full bg-mary transition-[width] duration-700"
            style={{ width: `${maryScore * 10}%` }}
          />
        </div>
        <span className="w-8 text-right font-mono text-sm tabular-nums">{formatScore(maryScore)}</span>
      </div>
      <div className="flex items-center gap-3">
        <span className="w-16 shrink-0 font-mono text-[0.65rem] uppercase tracking-[0.14em] text-risen">
          Risen
        </span>
        <div className="h-[3px] flex-1 bg-rule">
          <div
            className="h-full bg-risen transition-[width] duration-700"
            style={{ width: `${risenScore * 10}%` }}
          />
        </div>
        <span className="w-8 text-right font-mono text-sm tabular-nums">{formatScore(risenScore)}</span>
      </div>
    </div>
  );
}

function SiteCard({ site, accent }: { site: SiteProfile; accent: "mary" | "risen" }) {
  const isMary = accent === "mary";
  return (
    <article className="flex h-full flex-col overflow-hidden border border-rule bg-cream shadow-[0_24px_60px_-32px_rgba(23,20,15,0.45)]">
      <div className="relative aspect-[16/10] overflow-hidden bg-ink">
        <img
          src={site.images.hero}
          alt={`${site.name} at dusk`}
          className="h-full w-full object-cover"
          onError={(event) => {
            event.currentTarget.src = "/images/review-hero.jpg";
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/10 to-transparent" />
        <p className="absolute bottom-4 left-4 right-4 font-display text-2xl text-cream italic sm:text-3xl">
          {site.tagline}
        </p>
      </div>
      <div className="flex flex-1 flex-col p-6 sm:p-8">
        <p
          className={cn(
            "font-mono text-[0.65rem] uppercase tracking-[0.22em]",
            isMary ? "text-mary" : "text-risen",
          )}
        >
          {site.place} · v{site.version}
        </p>
        <h3 className="mt-2 font-display text-2xl leading-tight text-balance sm:text-3xl">{site.name}</h3>
        <p className="mt-1 text-sm text-muted">{site.chinese}</p>
        <dl className="mt-6 grid grid-cols-2 gap-x-4 gap-y-3 text-sm">
          <div>
            <dt className="font-mono text-[0.62rem] uppercase tracking-[0.16em] text-muted">Vision</dt>
            <dd className="mt-0.5">{site.vision}</dd>
          </div>
          <div>
            <dt className="font-mono text-[0.62rem] uppercase tracking-[0.16em] text-muted">Feast</dt>
            <dd className="mt-0.5">{site.feast}</dd>
          </div>
          <div>
            <dt className="font-mono text-[0.62rem] uppercase tracking-[0.16em] text-muted">Founded</dt>
            <dd className="mt-0.5">{site.founded}</dd>
          </div>
          <div>
            <dt className="font-mono text-[0.62rem] uppercase tracking-[0.16em] text-muted">Round</dt>
            <dd className="mt-0.5">{site.designRound}</dd>
          </div>
        </dl>
        <p className="mt-5 text-sm leading-relaxed text-ink-soft">{site.heroLine}</p>
        <div className="mt-auto flex flex-wrap gap-4 pt-6 text-sm">
          <a
            href={site.live}
            target="_blank"
            rel="noreferrer"
            className={cn(
              "font-medium underline decoration-from-font underline-offset-4",
              isMary ? "text-mary" : "text-risen",
            )}
          >
            Open live site
          </a>
          <a
            href={site.github}
            target="_blank"
            rel="noreferrer"
            className="text-ink-soft underline decoration-rule underline-offset-4 hover:text-ink"
          >
            GitHub
          </a>
        </div>
      </div>
    </article>
  );
}

export default function App() {
  const [active, setActive] = useState("overview");
  const [openId, setOpenId] = useState(dimensions[0]?.id ?? "identity");

  useEffect(() => {
    const ids = NAV.map((n) => n.href.slice(1));
    const nodes = ids
      .map((id) => document.getElementById(id))
      .filter((n): n is HTMLElement => n !== null);

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target.id) setActive(visible.target.id);
      },
      { rootMargin: "-20% 0px -60% 0px", threshold: [0.1, 0.25, 0.5] },
    );

    nodes.forEach((n) => observer.observe(n));
    return () => observer.disconnect();
  }, []);

  const openDimension = useMemo(
    () => dimensions.find((d) => d.id === openId) ?? dimensions[0],
    [openId],
  );

  return (
    <div className="relative min-h-screen">
      <div className="grain pointer-events-none fixed inset-0 z-50" />
      <a href="#overview" className="skip-link">
        Skip to content
      </a>

      <header className="sticky top-0 z-40 border-b border-rule/80 bg-paper/85 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-5 py-3 sm:px-8">
          <a href="#overview" className="font-display text-lg tracking-tight">
            Sister Shrines
          </a>
          <nav aria-label="Sections" className="hidden items-center gap-5 lg:flex">
            {NAV.map((item) => {
              const id = item.href.slice(1);
              return (
                <a
                  key={item.href}
                  href={item.href}
                  aria-current={active === id ? "true" : undefined}
                  className={cn(
                    "relative font-mono text-[0.68rem] uppercase tracking-[0.16em] text-muted transition-colors hover:text-ink",
                    active === id && "text-ink after:absolute after:inset-x-0 after:-bottom-3 after:h-px after:bg-mark",
                  )}
                >
                  {item.label}
                </a>
              );
            })}
          </nav>
          <p className="hidden font-mono text-[0.62rem] uppercase tracking-[0.18em] text-muted sm:block">
            Audit · 2026
          </p>
        </div>
      </header>

      <main>
        <section className="relative isolate overflow-hidden bg-ink text-cream">
          <img
            src="/images/review-hero.jpg"
            alt=""
            className="absolute inset-0 h-full w-full object-cover opacity-45"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/80 to-ink/40" />
          <div className="relative mx-auto max-w-6xl px-5 py-20 sm:px-8 sm:py-28 lg:py-36">
            <p className="font-mono text-[0.7rem] uppercase tracking-[0.28em] text-gold">
              Visual aesthetic · UI/UX · two live parish sites
            </p>
            <h1 className="mt-5 max-w-4xl font-display text-4xl leading-[1.05] text-balance sm:text-6xl lg:text-7xl">
              Two households.
              <span className="italic text-cream/80"> One shrine system.</span>
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-relaxed text-cream/75">
              St Mary of the Angels and the Church of the Risen Christ are sister ports of the
              same warm-editorial chassis. The interesting question is not whether they look alike —
              they do — but where craft, honesty, and place diverge.
            </p>
            <dl className="mt-12 grid max-w-xl grid-cols-3 gap-6 border-t border-cream/15 pt-8">
              <div>
                <dt className="font-mono text-[0.62rem] uppercase tracking-[0.18em] text-gold">Aesthetic</dt>
                <dd className="mt-1 font-display text-3xl">{formatScore(aesthetic.mary)} / {formatScore(aesthetic.risen)}</dd>
                <dd className="text-xs text-cream/55">Mary leads on place</dd>
              </div>
              <div>
                <dt className="font-mono text-[0.62rem] uppercase tracking-[0.18em] text-gold">UX craft</dt>
                <dd className="mt-1 font-display text-3xl">{formatScore(ux.mary)} / {formatScore(ux.risen)}</dd>
                <dd className="text-xs text-cream/55">Risen leads on honesty</dd>
              </div>
              <div>
                <dt className="font-mono text-[0.62rem] uppercase tracking-[0.18em] text-gold">Overall</dt>
                <dd className="mt-1 font-display text-3xl">{formatScore(overall.mary)} / {formatScore(overall.risen)}</dd>
                <dd className="text-xs text-cream/55">Risen Christ, narrowly</dd>
              </div>
            </dl>
          </div>
        </section>

        <section id="overview" className="scroll-mt-20 border-b border-rule">
          <div className="mx-auto grid max-w-6xl gap-12 px-5 py-16 sm:px-8 lg:grid-cols-[1.1fr_0.9fr] lg:py-24">
            <div>
              <p className="font-mono text-[0.68rem] uppercase tracking-[0.22em] text-mark">01 — Method</p>
              <h2 className="mt-3 font-display text-4xl text-balance sm:text-5xl">
                A journal review, not a screenshot contest.
              </h2>
              <div className="mt-6 space-y-4 text-[1.05rem] leading-relaxed text-ink-soft">
                <p>
                  Both live hosts are single-file React SPAs. Fetching the HTML yields an empty
                  <code className="mx-1 font-mono text-[0.85em] text-ink">#root</code>
                  — so this audit is grounded in source, design docs, and the inlined production CSS,
                  not in a rendered DOM crawl.
                </p>
                <p>
                  Inspected: live <code className="font-mono text-[0.85em]">index.html</code> (fonts,
                  CSP, skip-link, theme-color), both GitHub trees, <code className="font-mono text-[0.85em]">src/index.css</code>,
                  Home / PageHero / content data, and the round-5 and round-7 design enhancement
                  ledgers. Scores are out of 10.
                </p>
              </div>
            </div>
            <aside className="border border-rule bg-paper-2/60 p-6 sm:p-8">
              <h3 className="font-display text-2xl">Verification ledger</h3>
              <ul className="mt-5 space-y-4 text-sm leading-relaxed">
                <li className="flex gap-3">
                  <ConfidenceChip value="Verified" />
                  <span>Tokens, fonts, routing, Home structure, card-lift vs card-tint, skip-link CSS, CSP img-src.</span>
                </li>
                <li className="flex gap-3">
                  <ConfidenceChip value="Reasoned" />
                  <span>PageHero atmosphere, skip-link contrast, print/reveal robustness, parish-character judgment.</span>
                </li>
                <li className="flex gap-3">
                  <ConfidenceChip value="Assumed" />
                  <span>Pixel-perfect live layout at 390 / 1440 — not captured in this environment. Round-7 docs include those shots.</span>
                </li>
              </ul>
              <p className="mt-6 text-xs leading-relaxed text-muted">
                Lineage is documented in the Risen Christ README: Rother → St Joseph → St Mary →
                Risen. Comparing them is comparing a chassis to its later, more honest tune.
              </p>
            </aside>
          </div>
        </section>

        <section id="portraits" className="scroll-mt-20 border-b border-rule bg-paper-2/40">
          <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 lg:py-24">
            <p className="font-mono text-[0.68rem] uppercase tracking-[0.22em] text-mark">02 — The parishes</p>
            <h2 className="mt-3 max-w-3xl font-display text-4xl text-balance sm:text-5xl">
              Same rooms. Different households.
            </h2>
            <div className="mt-12 grid gap-8 lg:grid-cols-2">
              <SiteCard site={mary} accent="mary" />
              <SiteCard site={risen} accent="risen" />
            </div>
            <div className="mt-10 grid gap-4 sm:grid-cols-3">
              <figure className="overflow-hidden border border-rule">
                <img
                  src={mary.images.sanctuary}
                  alt="Sanctuary of St Mary of the Angels"
                  className="aspect-[4/3] w-full object-cover"
                  onError={(event) => {
                    event.currentTarget.src = "/images/swatch-mary.jpg";
                  }}
                />
                <figcaption className="bg-cream px-3 py-2 font-mono text-[0.62rem] uppercase tracking-[0.16em] text-muted">
                  St Mary · sanctuary
                </figcaption>
              </figure>
              <figure className="overflow-hidden border border-rule">
                <img
                  src={risen.images.sanctuary}
                  alt="Sanctuary of the Church of the Risen Christ"
                  className="aspect-[4/3] w-full object-cover"
                  onError={(event) => {
                    event.currentTarget.src = "/images/swatch-risen.jpg";
                  }}
                />
                <figcaption className="bg-cream px-3 py-2 font-mono text-[0.62rem] uppercase tracking-[0.16em] text-muted">
                  Risen Christ · sanctuary
                </figcaption>
              </figure>
              <figure className="overflow-hidden border border-rule">
                <img
                  src={mary.images.glass}
                  alt="Stained glass from the St Mary site"
                  className="aspect-[4/3] w-full object-cover"
                  onError={(event) => {
                    event.currentTarget.src = "/images/swatch-mary.jpg";
                  }}
                />
                <figcaption className="bg-cream px-3 py-2 font-mono text-[0.62rem] uppercase tracking-[0.16em] text-muted">
                  Shared motif · stained glass
                </figcaption>
              </figure>
            </div>
          </div>
        </section>

        <section id="scores" className="scroll-mt-20 border-b border-rule">
          <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 lg:py-24">
            <p className="font-mono text-[0.68rem] uppercase tracking-[0.22em] text-mark">03 — The board</p>
            <h2 className="mt-3 font-display text-4xl sm:text-5xl">Ten dimensions, one chassis.</h2>
            <p className="mt-4 max-w-2xl leading-relaxed text-ink-soft">
              Equal weights. Aesthetic cluster is identity, type, atmosphere, character.
              UX cluster is motion, IA, honesty, wayfinding, accessibility, closure.
            </p>

            <div className="mt-12 grid gap-4 sm:grid-cols-3">
              {[
                { label: "Aesthetic", mary: aesthetic.mary, risen: aesthetic.risen, note: "St Mary, by place" },
                { label: "UX craft", mary: ux.mary, risen: ux.risen, note: "Risen, by honesty" },
                { label: "Combined", mary: overall.mary, risen: overall.risen, note: "Risen Christ" },
              ].map((card) => (
                <div key={card.label} className="border border-rule bg-cream p-6">
                  <p className="font-mono text-[0.65rem] uppercase tracking-[0.18em] text-muted">{card.label}</p>
                  <p className="mt-3 font-display text-4xl tabular-nums">
                    {formatScore(card.mary)}
                    <span className="mx-2 text-2xl text-rule">/</span>
                    {formatScore(card.risen)}
                  </p>
                  <p className="mt-2 text-sm text-muted">{card.note}</p>
                  <div className="mt-5">
                    <ScoreBar maryScore={card.mary} risenScore={card.risen} />
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-10 overflow-x-auto border border-rule">
              <table className="w-full min-w-[640px] text-left text-sm">
                <caption className="sr-only">Dimension scores for both parish sites</caption>
                <thead className="bg-paper-2 font-mono text-[0.65rem] uppercase tracking-[0.16em] text-muted">
                  <tr>
                    <th className="px-4 py-3 font-medium">Dimension</th>
                    <th className="px-4 py-3 font-medium">St Mary</th>
                    <th className="px-4 py-3 font-medium">Risen Christ</th>
                    <th className="px-4 py-3 font-medium">Leads</th>
                    <th className="px-4 py-3 font-medium">Confidence</th>
                  </tr>
                </thead>
                <tbody>
                  {dimensions.map((d) => (
                    <tr key={d.id} className="border-t border-rule">
                      <td className="px-4 py-3">
                        <button
                          type="button"
                          onClick={() => {
                            setOpenId(d.id);
                            document.getElementById("dimensions")?.scrollIntoView({ behavior: "smooth" });
                          }}
                          className="text-left font-medium hover:text-mark"
                        >
                          {d.name}
                        </button>
                      </td>
                      <td className={cn("px-4 py-3 font-mono tabular-nums", d.winner === "mary" && "text-mary")}>
                        {formatScore(d.mary)}
                      </td>
                      <td className={cn("px-4 py-3 font-mono tabular-nums", d.winner === "risen" && "text-risen")}>
                        {formatScore(d.risen)}
                      </td>
                      <td className="px-4 py-3">{winnerLabel(d.winner)}</td>
                      <td className="px-4 py-3">
                        <ConfidenceChip value={d.confidence} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>

        <section id="system" className="scroll-mt-20 border-b border-rule bg-ink text-cream">
          <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 lg:py-24">
            <p className="font-mono text-[0.68rem] uppercase tracking-[0.22em] text-gold">04 — Shared blood</p>
            <h2 className="mt-3 max-w-3xl font-display text-4xl text-balance sm:text-5xl">
              The shrine system is the story behind the story.
            </h2>
            <p className="mt-5 max-w-2xl leading-relaxed text-cream/70">
              Comparing these sites as if they were independent designs would be dishonest.
              They share tokens, type, motion, IA, and the cream–maroon–gold liturgical voice.
            </p>

            <div className="mt-12 grid gap-3 sm:grid-cols-4">
              {tokens.map((t) => (
                <div key={t.name} className="border border-cream/15 p-4">
                  <div className="h-14 w-full" style={{ background: t.hex }} />
                  <p className="mt-3 font-mono text-[0.65rem] uppercase tracking-[0.14em] text-gold">{t.name}</p>
                  <p className="font-mono text-xs text-cream/80">{t.hex}</p>
                  <p className="mt-1 text-xs text-cream/55">{t.use}</p>
                </div>
              ))}
            </div>

            <ul className="mt-12 grid gap-3 sm:grid-cols-2">
              {shared.map((item) => (
                <li key={item} className="border-l border-gold/40 pl-4 text-sm leading-relaxed text-cream/75">
                  {item}
                </li>
              ))}
            </ul>

            <div className="mt-12 grid gap-6 lg:grid-cols-2">
              <figure className="overflow-hidden border border-cream/15">
                <img src="/images/swatch-mary.jpg" alt="Material still life in oxblood, cream, gold, and pine — the St Mary register" className="aspect-[16/9] w-full object-cover" />
                <figcaption className="px-4 py-3 font-mono text-[0.65rem] uppercase tracking-[0.16em] text-cream/50">
                  St Mary register — oxblood, parchment, pine
                </figcaption>
              </figure>
              <figure className="overflow-hidden border border-cream/15">
                <img src="/images/swatch-risen.jpg" alt="Material still life in warmer gold and wine — the Risen Christ register" className="aspect-[16/9] w-full object-cover" />
                <figcaption className="px-4 py-3 font-mono text-[0.65rem] uppercase tracking-[0.16em] text-cream/50">
                  Risen register — same cloth, warmer light
                </figcaption>
              </figure>
            </div>
          </div>
        </section>

        <section id="dimensions" className="scroll-mt-20 border-b border-rule">
          <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 lg:py-24">
            <p className="font-mono text-[0.68rem] uppercase tracking-[0.22em] text-mark">05 — Close reading</p>
            <h2 className="mt-3 font-display text-4xl sm:text-5xl">Where they actually differ.</h2>

            <div className="mt-10 grid gap-8 lg:grid-cols-[0.38fr_0.62fr]">
              <div className="flex flex-col gap-1 lg:sticky lg:top-24 lg:self-start" role="tablist" aria-label="Score dimensions">
                {dimensions.map((d) => {
                  const selected = d.id === openDimension.id;
                  return (
                    <button
                      key={d.id}
                      type="button"
                      role="tab"
                      aria-selected={selected}
                      onClick={() => setOpenId(d.id)}
                      className={cn(
                        "flex items-baseline justify-between gap-3 border px-4 py-3 text-left transition-colors",
                        selected
                          ? "border-ink bg-ink text-cream"
                          : "border-rule bg-cream hover:border-ink/40",
                      )}
                    >
                      <span className="font-display text-lg">{d.name}</span>
                      <span className={cn("font-mono text-xs tabular-nums", selected ? "text-gold" : "text-muted")}>
                        {formatScore(d.mary)} · {formatScore(d.risen)}
                      </span>
                    </button>
                  );
                })}
              </div>

              <article className="border border-rule bg-cream p-6 sm:p-10" role="tabpanel">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <p className="font-mono text-[0.65rem] uppercase tracking-[0.18em] text-mark">
                    Leads · {winnerLabel(openDimension.winner)}
                  </p>
                  <ConfidenceChip value={openDimension.confidence} />
                </div>
                <h3 className="mt-4 font-display text-3xl text-balance sm:text-4xl">{openDimension.thesis}</h3>
                <div className="mt-8">
                  <ScoreBar maryScore={openDimension.mary} risenScore={openDimension.risen} />
                </div>
                <div className="mt-10 grid gap-8 sm:grid-cols-2">
                  <div>
                    <p className="font-mono text-[0.65rem] uppercase tracking-[0.16em] text-mary">St Mary</p>
                    <p className="mt-2 leading-relaxed text-ink-soft">{openDimension.maryNote}</p>
                  </div>
                  <div>
                    <p className="font-mono text-[0.65rem] uppercase tracking-[0.16em] text-risen">Risen Christ</p>
                    <p className="mt-2 leading-relaxed text-ink-soft">{openDimension.risenNote}</p>
                  </div>
                </div>
                <p className="mt-8 border-t border-rule pt-6 text-sm leading-relaxed text-muted">
                  <span className="font-mono text-[0.62rem] uppercase tracking-[0.16em] text-ink">Evidence · </span>
                  {openDimension.evidence}
                </p>
              </article>
            </div>
          </div>
        </section>

        <section id="findings" className="scroll-mt-20 border-b border-rule bg-paper-2/50">
          <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 lg:py-24">
            <p className="font-mono text-[0.68rem] uppercase tracking-[0.22em] text-mark">06 — Findings</p>
            <h2 className="mt-3 font-display text-4xl sm:text-5xl">What I would fix first.</h2>
            <p className="mt-4 max-w-2xl leading-relaxed text-ink-soft">
              Ordered by severity. Nothing here is invented for thoroughness — if the chassis is
              clean, the remaining issues are the ones that still change how a pilgrim feels.
            </p>
            <ol className="mt-12 space-y-4">
              {findings.map((f, i) => (
                <li key={f.title} className="grid gap-4 border border-rule bg-cream p-6 sm:grid-cols-[7rem_1fr] sm:p-8">
                  <div>
                    <p className="font-mono text-[0.65rem] uppercase tracking-[0.16em] text-muted">
                      {String(i + 1).padStart(2, "0")}
                    </p>
                    <p
                      className={cn(
                        "mt-2 font-mono text-[0.65rem] uppercase tracking-[0.14em]",
                        f.severity === "High" && "text-mark",
                        f.severity === "Medium" && "text-mary",
                        f.severity === "Low" && "text-gold",
                        f.severity === "Informational" && "text-muted",
                      )}
                    >
                      {f.severity}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-[0.14em] text-muted">{f.site}</p>
                    <h3 className="mt-1 font-display text-2xl">{f.title}</h3>
                    <p className="mt-3 leading-relaxed text-ink-soft">{f.detail}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
        </section>

        <section id="verdict" className="scroll-mt-20 bg-ink text-cream">
          <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 lg:py-28">
            <p className="font-mono text-[0.68rem] uppercase tracking-[0.22em] text-gold">07 — Verdict</p>
            <h2 className="mt-3 max-w-4xl font-display text-4xl leading-tight text-balance sm:text-6xl">
              Risen Christ is the better interface.
              <span className="italic text-cream/70"> St Mary is the better parish.</span>
            </h2>
            <div className="mt-10 grid gap-10 lg:grid-cols-2">
              <div className="space-y-4 text-lg leading-relaxed text-cream/75">
                <p>
                  On UX — hover honesty, wayfinding hairlines, ministries scrollspy, print-safe
                  reveals, featured PayNow, closure bands — Risen Christ is simply two design rounds
                  later. Round 7 “Honest Light” is the difference between a beautiful template and a
                  considerate one.
                </p>
                <p>
                  On aesthetic soul, St Mary still wins. The WOHA nave, the Portiuncula name, the
                  friars, “According to Thy Word.” The sentences could not be swapped onto Toa Payoh
                  without becoming false. Risen Christ’s facts are equally local; its coat of paint
                  is not yet its own.
                </p>
              </div>
              <div className="border border-cream/15 p-8">
                <p className="font-mono text-[0.65rem] uppercase tracking-[0.18em] text-gold">If only one lesson travels</p>
                <p className="mt-4 font-display text-3xl leading-snug text-balance">
                  Lift is a promise. Tint is a courtesy. Never lift a card that does not go somewhere.
                </p>
                <p className="mt-6 text-sm leading-relaxed text-cream/60">
                  Port the round-7 kit back to Bukit Batok: card-tint, nav hairline, PageHero
                  atmosphere, reveal print override, News/FAQ closure, ministries spy. Then give
                  Toa Payoh a palette that is Easter, not shrine-maroon by inheritance.
                </p>
                <div className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-sm">
                  <a href={mary.live} className="text-gold underline underline-offset-4" target="_blank" rel="noreferrer">
                    st-mary-of-angels.jesspete.shop
                  </a>
                  <a href={risen.live} className="text-gold underline underline-offset-4" target="_blank" rel="noreferrer">
                    risen-christ.jesspete.shop
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-rule bg-paper">
        <div className="mx-auto flex max-w-6xl flex-col gap-3 px-5 py-8 text-sm text-muted sm:flex-row sm:items-center sm:justify-between sm:px-8">
          <p>Sister Shrines — a visual &amp; UX audit of two Archdiocese of Singapore parish ports.</p>
          <p className="font-mono text-[0.65rem] uppercase tracking-[0.14em]">
            Scores reasoned from source · not a live screenshot lab
          </p>
        </div>
      </footer>
    </div>
  );
}
